/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Student, Classroom, AttendanceRecord, AttendanceStatus, NotificationTemplate, NotificationLog } from '../types';
import { Check, Mail, AlertCircle, Sparkles, CheckSquare, RefreshCw, Calendar, Send } from 'lucide-react';

interface AttendanceRegisterProps {
  students: Student[];
  classrooms: Classroom[];
  records: AttendanceRecord[];
  templates: NotificationTemplate[];
  onSaveAttendance: (
    newRecords: AttendanceRecord[], 
    generatedNotifications: NotificationLog[]
  ) => void;
}

export default function AttendanceRegister({
  students,
  classrooms,
  records,
  templates,
  onSaveAttendance
}: AttendanceRegisterProps) {

  // Current states
  const [selectedClassId, setSelectedClassId] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>('2026-06-16'); // Current local date
  const [registerStates, setRegisterStates] = useState<{
    [studentId: string]: {
      status: AttendanceStatus;
      notes: string;
    };
  }>({});
  const [autoNotify, setAutoNotify] = useState<boolean>(true);
  const [wasSaved, setWasSaved] = useState<boolean>(false);

  // Default class selection
  useEffect(() => {
    if (classrooms.length > 0 && !selectedClassId) {
      setSelectedClassId(classrooms[0].id);
    }
  }, [classrooms, selectedClassId]);

  // Load existing records for the classroom + date if they already exist
  const activeClassStudents = students.filter(s => s.classId === selectedClassId);

  useEffect(() => {
    if (!selectedClassId || !selectedDate) return;

    const updatedStates: typeof registerStates = {};
    activeClassStudents.forEach(student => {
      // Find existing record
      const match = records.find(r => r.studentId === student.id && r.date === selectedDate);
      if (match) {
        updatedStates[student.id] = {
          status: match.status,
          notes: match.notes || ''
        };
      } else {
        // Default to 'Present'
        updatedStates[student.id] = {
          status: 'Present',
          notes: ''
        };
      }
    });

    setRegisterStates(updatedStates);
    setWasSaved(false);
  }, [selectedClassId, selectedDate, records]);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setRegisterStates(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        status
      }
    }));
    setWasSaved(false);
  };

  const handleNotesChange = (studentId: string, notes: string) => {
    setRegisterStates(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        notes
      }
    }));
  };

  const handleMarkAllPresent = () => {
    const updated = { ...registerStates };
    activeClassStudents.forEach(s => {
      if (updated[s.id]) {
        updated[s.id] = {
          ...updated[s.id],
          status: 'Present'
        };
      }
    });
    setRegisterStates(updated);
  };

  // Helper to substitute templates
  const substituteTemplate = (
    template: string, 
    student: Student, 
    classroomName: string, 
    date: string
  ): string => {
    return template
      .replace(/{student_name}/g, student.name)
      .replace(/{parent_name}/g, student.parentName)
      .replace(/{classroom}/g, classroomName)
      .replace(/{date}/g, date);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClassId) return;

    const classroomObj = classrooms.find(c => c.id === selectedClassId);
    const className = classroomObj ? classroomObj.name : 'Unknown Class';

    const newRecordsList: AttendanceRecord[] = [];
    const newNotificationsList: NotificationLog[] = [];

    activeClassStudents.forEach(student => {
      const state = registerStates[student.id] || { status: 'Present', notes: '' };
      
      // Look up previous record to avoid spamming notification if the status remains identical
      const originalRecord = records.find(r => r.studentId === student.id && r.date === selectedDate);
      const isStatusChanged = !originalRecord || originalRecord.status !== state.status;

      // Create attendance record
      const recordItem: AttendanceRecord = {
        id: `att_${student.id}_${selectedDate}`,
        studentId: student.id,
        classId: selectedClassId,
        date: selectedDate,
        status: state.status,
        notes: state.notes ? state.notes : undefined,
        markedAt: new Date().toISOString()
      };
      newRecordsList.push(recordItem);

      // Trigger automatic notification (only on Absence/Tardy trigger if status changed or wasn't logged before, and feature is checked)
      if (autoNotify && isStatusChanged && (state.status === 'Absent' || state.status === 'Tardy')) {
        const triggerType = state.status === 'Absent' ? 'Absent' : 'Tardy';
        const activeTemplate = templates.find(t => t.type === triggerType && t.enabled);

        if (activeTemplate) {
          const subject = substituteTemplate(activeTemplate.subjectTemplate, student, className, selectedDate);
          const body = substituteTemplate(activeTemplate.bodyTemplate, student, className, selectedDate);

          const newNotification: NotificationLog = {
            id: `not_${Date.now()}_${student.id}`,
            studentId: student.id,
            studentName: student.name,
            className: className,
            parentName: student.parentName,
            parentEmail: student.parentEmail,
            statusTrigger: triggerType,
            date: selectedDate,
            emailSubject: subject,
            emailBody: body,
            sentAt: new Date().toISOString(),
            status: 'Delivered' // Simulated successful mail hook delivery
          };
          
          newNotificationsList.push(newNotification);
        }
      }
    });

    onSaveAttendance(newRecordsList, newNotificationsList);
    setWasSaved(true);

    // Auto dismiss high-contrast banner after 3.5s
    setTimeout(() => {
      setWasSaved(false);
    }, 4000);
  };

  return (
    <div className="space-y-6" id="attendance_register_module">
      
      {/* Search Header Options */}
      <div className="bg-white border border-slate-150 rounded-2xl p-5 shadow-xs">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            
            {/* Custom selects */}
            <div className="flex-1 w-full">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5 label_for_field">
                Select Class Section
              </label>
              <select
                id="select_register_class"
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-4 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all cursor-pointer"
              >
                {classrooms.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.roomNumber})</option>
                ))}
              </select>
            </div>

            {/* Date Input */}
            <div className="w-full md:w-56">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1.5 label_for_field">
                Attendance Date
              </label>
              <div className="relative">
                <input
                  type="date"
                  id="input_register_date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded-xl px-4 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all"
                />
              </div>
            </div>

            {/* Quick action buttons */}
            <div className="flex w-full md:w-auto gap-2">
              <button
                type="button"
                onClick={handleMarkAllPresent}
                id="btn_mark_all_present"
                disabled={activeClassStudents.length === 0}
                className="w-full md:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-50 border border-slate-250 text-slate-700 rounded-xl hover:bg-slate-100 font-semibold cursor-pointer text-xs disabled:opacity-50 disabled:cursor-not-allowed transition-all shrink-0"
              >
                <CheckSquare size={14} />
                Set All Present
              </button>

              <button
                type="submit"
                id="btn_submit_register_sheet"
                disabled={activeClassStudents.length === 0}
                className="w-full md:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-slate-900 border border-slate-950 hover:bg-slate-850 text-white rounded-xl font-semibold cursor-pointer text-xs disabled:opacity-50 disabled:cursor-not-allowed transition-all shrink-0 shadow-xs"
              >
                <Send size={14} />
                Save Roll Call
              </button>
            </div>

          </div>

          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pt-3 border-t border-slate-100 gap-3">
            
            {/* Automatic notification toggle trigger */}
            <label className="inline-flex items-center gap-2 cursor-pointer group" id="notify_parents_toggle_wrapper">
              <input
                type="checkbox"
                id="checkbox_auto_notify_parents"
                checked={autoNotify}
                onChange={(e) => setAutoNotify(e.target.checked)}
                className="w-4 h-4 text-slate-900 border-slate-300 rounded-xs focus:ring-slate-900 cursor-pointer"
              />
              <span className="text-xs text-slate-600 font-medium group-hover:text-slate-900 select-none transition-colors">
                Enable automated real-time email notification logs for parents
              </span>
            </label>

            {wasSaved && (
              <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 border border-emerald-150 rounded-lg text-xs font-semibold animate-bounce" id="register_success_msg">
                <Check size={14} />
                Attendance updated! Parent triggers processed.
              </span>
            )}
          </div>
        </form>
      </div>

      {/* Main Students List Grid Form */}
      <div className="bg-white border border-slate-150 rounded-2xl overflow-hidden shadow-xs">
        
        {/* Table Titles */}
        <div className="bg-slate-50 border-b border-secondary-100 py-3.5 px-6 grid grid-cols-1 md:grid-cols-12 text-xs font-bold text-slate-505 uppercase tracking-wider gap-4">
          <div className="md:col-span-4 flex items-center">Student details</div>
          <div className="md:col-span-5 flex items-center justify-center md:justify-start">Record Attendance Status</div>
          <div className="md:col-span-3 flex items-center">Action Notes</div>
        </div>

        {/* Student items */}
        <div className="divide-y divide-slate-100" id="classroom_students_register">
          {activeClassStudents.length > 0 ? (
            activeClassStudents.map((student) => {
              const studentState = registerStates[student.id] || { status: 'Present', notes: '' };
              const currentStatus = studentState.status;

              return (
                <div 
                  key={student.id} 
                  className="p-5 grid grid-cols-1 md:grid-cols-12 items-center gap-4 hover:bg-slate-50/50 transition-colors"
                  id={`register_item_${student.id}`}
                >
                  
                  {/* Item block 1: Info */}
                  <div className="md:col-span-4 flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-full ${student.avatarColor} text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-xs`}>
                      {student.name.split(' ').map(n => n.charAt(0)).join('')}
                    </div>
                    <div className="min-w-0">
                      <span className="font-semibold text-slate-800 text-sm block truncate">{student.name}</span>
                      <span className="text-[11px] font-mono text-slate-450 block">{student.rollNumber}</span>
                    </div>
                  </div>

                  {/* Item block 2: Action status selectors */}
                  <div className="md:col-span-5 flex flex-wrap gap-1.5 items-center justify-start md:row-auto">
                    
                    {/* Status Pill Present */}
                    <button
                      type="button"
                      id={`status_${student.id}_Present`}
                      onClick={() => handleStatusChange(student.id, 'Present')}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                        currentStatus === 'Present'
                          ? 'bg-emerald-500 text-white shadow-xs'
                          : 'bg-emerald-50/50 text-emerald-700 hover:bg-emerald-100 border border-emerald-100/30'
                      }`}
                    >
                      Present
                    </button>

                    {/* Status Pill Absent */}
                    <button
                      type="button"
                      id={`status_${student.id}_Absent`}
                      onClick={() => handleStatusChange(student.id, 'Absent')}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                        currentStatus === 'Absent'
                          ? 'bg-red-500 text-white shadow-xs'
                          : 'bg-red-50/50 text-red-700 hover:bg-red-100 border border-red-100/30'
                      }`}
                    >
                      Absent
                    </button>

                    {/* Status Pill Tardy */}
                    <button
                      type="button"
                      id={`status_${student.id}_Tardy`}
                      onClick={() => handleStatusChange(student.id, 'Tardy')}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                        currentStatus === 'Tardy'
                          ? 'bg-amber-500 text-white shadow-xs'
                          : 'bg-amber-50/50 text-amber-700 hover:bg-amber-100 border border-amber-100/30'
                      }`}
                    >
                      Tardy
                    </button>

                    {/* Status Pill Excused */}
                    <button
                      type="button"
                      id={`status_${student.id}_Excused`}
                      onClick={() => handleStatusChange(student.id, 'Excused')}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer transition-all ${
                        currentStatus === 'Excused'
                          ? 'bg-blue-500 text-white shadow-xs'
                          : 'bg-indigo-50/50 text-indigo-700 hover:bg-indigo-100 border border-indigo-100/30'
                      }`}
                    >
                      Excused
                    </button>
                    
                  </div>

                  {/* Item block 3: Notes comment field */}
                  <div className="md:col-span-3">
                    <input
                      type="text"
                      placeholder="Add an attendance comment..."
                      id={`notes_input_${student.id}`}
                      value={studentState.notes}
                      onChange={(e) => handleNotesChange(student.id, e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-slate-900 transition-colors"
                    />
                  </div>

                </div>
              );
            })
          ) : (
            <div className="py-12 text-center text-slate-400">
              No students are currently catalogued inside the selected class list.
            </div>
          )}
        </div>

        {/* Footer info message */}
        {activeClassStudents.length > 0 && (
          <div className="bg-slate-50 py-3.5 px-6 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1">
              <AlertCircle size={14} className="text-slate-400" />
              Be sure to click "Save Roll Call" above to register changes and trigger automated logs.
            </span>
            <span className="font-medium">{activeClassStudents.length} students loaded.</span>
          </div>
        )}
      </div>

    </div>
  );
}
