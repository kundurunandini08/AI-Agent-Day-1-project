/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NotificationLog } from '../types';
import { Mail, ChevronRight, Inbox, Clock, RefreshCw, Send, ShieldCheck, CheckCircle2, Search } from 'lucide-react';

interface NotificationsLogViewProps {
  logs: NotificationLog[];
  onResendNotification: (logId: string) => void;
  onNavigateToTemplates: () => void;
}

export default function NotificationsLogView({
  logs,
  onResendNotification,
  onNavigateToTemplates
}: NotificationsLogViewProps) {

  const [selectedLogId, setSelectedLogId] = useState<string>('');
  const [resendingLogId, setResendingLogId] = useState<string>('');
  const [resendSuccess, setResendSuccess] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Handle active selected log selection
  const activeLogId = selectedLogId || (logs.length > 0 ? logs[0].id : '');
  const activeLog = logs.find(l => l.id === activeLogId);

  // Filter logs by search query (e.g. searching student name, email, subject)
  const filteredLogs = logs.filter(l => {
    return l.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           l.parentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
           l.parentEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
           l.emailSubject.toLowerCase().includes(searchQuery.toLowerCase());
  });

  const handleResend = (logId: string) => {
    setResendingLogId(logId);
    setResendSuccess(false);

    // Simulate network latency / dispatch delay
    setTimeout(() => {
      onResendNotification(logId);
      setResendingLogId('');
      setResendSuccess(true);
      
      // Dismiss success state
      setTimeout(() => setResendSuccess(false), 3000);
    }, 1000);
  };

  return (
    <div className="space-y-6" id="notifications_log_module">
      
      {/* Search Header panel */}
      <div className="bg-white border border-slate-150 rounded-2xl p-5 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:max-w-md">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            id="notification_log_search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search outbox by student, parent, or email..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900 text-slate-800"
          />
        </div>
        
        <div className="flex items-center gap-3 w-full sm:w-auto shrink-0 justify-end">
          <button
            onClick={onNavigateToTemplates}
            id="btn_log_manage_templates"
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-250 hover:bg-slate-50 px-3 py-2 rounded-xl transition-all cursor-pointer"
          >
            Manage Templates
          </button>
          
          <span className="text-xs text-slate-500 font-mono">
            Outbox Load: <strong>{logs.length} logged</strong>
          </span>
        </div>
      </div>

      {logs.length === 0 ? (
        <div className="bg-white border border-slate-150 rounded-2xl py-16 flex flex-col items-center justify-center text-center p-6">
          <Inbox size={48} className="text-slate-300 mb-3" />
          <h3 className="font-semibold text-slate-700 text-sm">Parent alert log is empty</h3>
          <p className="text-slate-400 text-xs mt-1 max-w-sm">
            When students are marked Absent or Tardy on current rosters, real-time parent notifications are generated here automatically.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start" id="outbox_layout_split">
          
          {/* LEFT LIST PANEL */}
          <div className="lg:col-span-5 bg-white border border-slate-150 rounded-2xl overflow-hidden shadow-xs h-[500px] flex flex-col">
            <div className="bg-slate-50 px-4 py-3 border-b border-slate-150 flex justify-between items-center shrink-0">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-widest">Outbox Logs</span>
              <span className="text-[10px] font-mono text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold border border-emerald-100">SMTP Active</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 custom-scrollbar" id="logs_list_pane">
              {filteredLogs.length > 0 ? (
                filteredLogs.map((log) => {
                  const isActive = log.id === activeLogId;
                  const isAbsent = log.statusTrigger === 'Absent';
                  
                  return (
                    <div
                      key={log.id}
                      onClick={() => setSelectedLogId(log.id)}
                      className={`p-4 cursor-pointer transition-all flex items-start gap-3 relative ${
                        isActive 
                          ? 'bg-slate-50 border-l-4 border-slate-900' 
                          : 'hover:bg-slate-50/50'
                      }`}
                      id={`log_item_${log.id}`}
                    >
                      <div className={`p-2.5 rounded-xl shrink-0 ${
                        isAbsent ? 'bg-red-50 text-red-500' : 'bg-amber-50 text-amber-500'
                      }`}>
                        <Mail size={16} />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="font-semibold text-xs text-slate-800 truncate">
                            {log.studentName}
                          </span>
                          <span className="text-[9px] text-slate-400 font-mono white-space-nowrap shrink-0">
                            {new Date(log.sentAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        
                        <p className="text-[11px] text-slate-600 truncate mb-1">
                          {log.emailSubject}
                        </p>
                        
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[10px] text-slate-450 truncate">
                            To: {log.parentEmail}
                          </span>
                          
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                            isAbsent ? 'bg-red-50 text-red-700 border border-red-100' : 'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}>
                            {log.statusTrigger}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="py-12 text-center text-slate-400 text-xs">
                  No notifications match search.
                </div>
              )}
            </div>
          </div>

          {/* RIGHT EMAIL BODY VIEWER */}
          <div className="lg:col-span-7 bg-white border border-slate-150 rounded-2xl overflow-hidden shadow-xs min-h-[500px] flex flex-col justify-between" id="outbox_viewer_pane">
            {activeLog ? (
              <div className="flex flex-col h-full flex-1">
                
                {/* Simulated mail client visual chrome header */}
                <div className="bg-slate-50/80 p-4 border-b border-light-100 flex items-center justify-between" id="mail_client_chrome">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-400"></div>
                    <div className="w-3 h-3 rounded-full bg-amber-400"></div>
                    <div className="w-3 h-3 rounded-full bg-emerald-400"></div>
                    <span className="text-xs font-semibold text-slate-500 ml-2 font-mono">Mail Delivery Viewer</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1 text-[11px] bg-emerald-50 text-emerald-800 border border-emerald-100 px-2.5 py-0.5 rounded-full font-bold">
                      <ShieldCheck size={12} />
                      {activeLog.status}
                    </span>
                  </div>
                </div>

                {/* Email details block */}
                <div className="p-5 border-b border-slate-100 space-y-3 bg-radial from-slate-50/30 to-transparent">
                  <div>
                    <h2 className="text-base font-bold text-slate-800 tracking-tight">
                      {activeLog.emailSubject}
                    </h2>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-650">
                    <div>
                      <span className="text-slate-450">From:</span>{' '}
                      <strong className="text-slate-700 font-mono">attendance-alerts@schoolportal.org</strong>
                    </div>
                    <div>
                      <span className="text-slate-450">Date:</span>{' '}
                      <span className="text-slate-600">
                        {new Date(activeLog.sentAt).toLocaleString('en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZoneName: 'short' })}
                      </span>
                    </div>
                    <div className="sm:col-span-2">
                      <span className="text-slate-450">To:</span>{' '}
                      <strong className="text-slate-800">{activeLog.parentName}</strong>{' '}
                      <span className="font-mono text-slate-500 font-medium text-[11px]">&lt;{activeLog.parentEmail}&gt;</span>
                    </div>
                  </div>
                </div>

                {/* Simulated parsed body content */}
                <div className="p-6 flex-1 bg-white text-slate-800 font-sans leading-relaxed text-sm whitespace-pre-wrap select-text custom-border border-dashed border-slate-100 m-4 rounded-xl shadow-xs" id="mail_body_card">
                  {activeLog.emailBody}
                </div>

                {/* Bottom Actions tab */}
                <div className="bg-slate-50 p-4 border-t border-slate-150 flex flex-col sm:flex-row justify-between items-center gap-3 mt-auto">
                  <div className="text-[11px] text-slate-450 flex items-center gap-1">
                    <Clock size={12} />
                    Auto-dispatched via active notification rule
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto">
                    {resendSuccess && (
                      <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-xs bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-100 animate-fade-in">
                        <CheckCircle2 size={13} />
                        Dispatched!
                      </span>
                    )}
                    
                    <button
                      type="button"
                      id="btn_resend_mail_alert"
                      onClick={() => handleResend(activeLog.id)}
                      disabled={!!resendingLogId}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-slate-900 border border-slate-950 text-white hover:bg-slate-850 rounded-xl font-semibold text-xs cursor-pointer select-none transition-all disabled:opacity-50"
                    >
                      {resendingLogId === activeLog.id ? (
                        <>
                          <RefreshCw size={13} className="animate-spin" />
                          Sending via SMTP...
                        </>
                      ) : (
                        <>
                          <Send size={12} />
                          Resend Parent Email Alert
                        </>
                      )}
                    </button>
                  </div>
                </div>

              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <Mail size={32} />
                <span className="text-xs font-semibold mt-2">Select a dispatch log to preview email</span>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
}
