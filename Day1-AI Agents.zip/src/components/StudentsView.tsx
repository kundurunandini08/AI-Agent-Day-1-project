/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Student, Classroom } from '../types';
import { Plus, Search, Trash2, Mail, Phone, User, Edit3, School } from 'lucide-react';

interface StudentsViewProps {
  students: Student[];
  classrooms: Classroom[];
  onAddStudent: (newStudent: Student) => void;
  onDeleteStudent: (studentId: string) => void;
}

export default function StudentsView({
  students,
  classrooms,
  onAddStudent,
  onDeleteStudent
}: StudentsViewProps) {

  // Search filter status
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedClassId, setSelectedClassId] = useState<string>('All');

  // New Student state Form
  const [name, setName] = useState('');
  const [rollNumber, setRollNumber] = useState('');
  const [classId, setClassId] = useState('');
  const [parentName, setParentName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [parentPhone, setParentPhone] = useState('');

  const [showAddForm, setShowAddForm] = useState(false);

  // Auto-populate first classroom when opening the form
  const handleOpenForm = () => {
    if (classrooms.length > 0 && !classId) {
      setClassId(classrooms[0].id);
    }
    setShowAddForm(!showAddForm);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !rollNumber || !classId || !parentName || !parentEmail) {
      alert('Please fill out all required fields marked *');
      return;
    }

    // Avatar color pool
    const colors = ['bg-emerald-500', 'bg-teal-500', 'bg-indigo-500', 'bg-violet-500', 'bg-sky-500', 'bg-pink-500', 'bg-rose-500', 'bg-amber-500', 'bg-orange-500'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const newStudent: Student = {
      id: `s_${Date.now()}`,
      name: name.trim(),
      rollNumber: rollNumber.trim().toUpperCase(),
      classId,
      parentName: parentName.trim(),
      parentEmail: parentEmail.trim(),
      parentPhone: parentPhone.trim() || '(555) 010-0000',
      avatarColor: randomColor
    };

    onAddStudent(newStudent);

    // Clear state
    setName('');
    setRollNumber('');
    setParentName('');
    setParentEmail('');
    setParentPhone('');
    setShowAddForm(false);
  };

  // Filter students based on search string & class list
  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          s.rollNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.parentEmail.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesClass = selectedClassId === 'All' || s.classId === selectedClassId;

    return matchesSearch && matchesClass;
  });

  return (
    <div className="space-y-6" id="students_directory_module">
      
      {/* Search and Form Header line */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white border border-slate-150 rounded-2xl p-5 shadow-xs gap-4">
        
        {/* Search controls */}
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto flex-1">
          <div className="relative flex-1 max-w-md">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search size={16} />
            </span>
            <input
              type="text"
              id="student_search_input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search pupils or roll codes..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all text-slate-800"
            />
          </div>

          <select
            id="student_class_filter"
            value={selectedClassId}
            onChange={(e) => setSelectedClassId(e.target.value)}
            className="bg-slate-55 border border-slate-200 text-slate-800 rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none cursor-pointer"
          >
            <option value="All">All Classrooms</option>
            {classrooms.map(c => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <button
          onClick={handleOpenForm}
          id="btn_toggle_add_student_form"
          className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-900 border border-slate-950 text-white hover:bg-slate-850 rounded-xl shadow-xs font-semibold text-xs cursor-pointer transition-all"
        >
          <Plus size={15} />
          {showAddForm ? 'Close panel' : 'Add Student'}
        </button>

      </div>

      {/* Add student subform panel */}
      {showAddForm && (
        <div className="bg-slate-50 border border-slate-200 p-6 rounded-2xl animate-fade-in" id="add_student_form_panel">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider mb-4 flex items-center gap-1.5">
            <User size={16} className="text-slate-600" />
            Enrol New Student Profile
          </h3>

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            <div className="space-y-4 md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Alexander Wright"
                  id="new_student_name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Student Roll / Registration Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="S102401"
                  id="new_student_roll"
                  value={rollNumber}
                  onChange={(e) => setRollNumber(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Class Assignment *
                </label>
                <select
                  required
                  id="new_student_class"
                  value={classId}
                  onChange={(e) => setClassId(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900 cursor-pointer text-slate-700"
                >
                  <option value="" disabled>Choose room...</option>
                  {classrooms.map(c => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Parent or Guardian Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Sarah Wright"
                  id="new_student_parent"
                  value={parentName}
                  onChange={(e) => setParentName(e.target.value)}
                  className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

            </div>

            <div className="bg-white border border-slate-150 p-4 rounded-xl space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Parent E-mail Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="sarah.w@example.com"
                  id="new_student_parent_email"
                  value={parentEmail}
                  onChange={(e) => setParentEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">Receives instant trigger notifications.</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
                  Parent Phone Number
                </label>
                <input
                  type="text"
                  placeholder="(555) 019-2831"
                  id="new_student_parent_phone"
                  value={parentPhone}
                  onChange={(e) => setParentPhone(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>
            </div>

            <div className="md:col-span-3 flex justify-end gap-3 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 text-slate-600 font-medium text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                id="btn_submit_add_student"
                className="px-5 py-2 bg-slate-900 hover:bg-slate-850 text-white hover:border-slate-800 rounded-xl font-semibold text-xs cursor-pointer shadow-xs"
              >
                Enroll student profile
              </button>
            </div>

          </form>
        </div>
      )}

      {/* Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5" id="students_directory_grid">
        {filteredStudents.length > 0 ? (
          filteredStudents.map((student) => {
            const classObj = classrooms.find(c => c.id === student.classId);

            return (
              <div 
                key={student.id} 
                className="bg-white border border-slate-150 rounded-2xl p-5 shadow-xs hover:shadow-sm hover:border-slate-300 transition-all group flex flex-col justify-between"
                id={`student_card_${student.id}`}
              >
                
                {/* Header section */}
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-10 h-10 rounded-full ${student.avatarColor} text-white font-bold text-xs flex items-center justify-center shrink-0 shadow-xs`}>
                      {student.name.split(' ').map(n => n.charAt(0)).join('')}
                    </div>
                    <div className="min-w-0">
                      <span className="font-bold text-slate-800 text-sm block group-hover:text-slate-900 truncate">
                        {student.name}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono block">
                        ID: {student.rollNumber}
                      </span>
                    </div>
                  </div>

                  {/* Delete student profile with confirmation */}
                  <button
                    onClick={() => {
                      if (window.confirm(`Are you sure you want to completely de-enrol ${student.name}? Past attendance logs will remains standard.`)) {
                        onDeleteStudent(student.id);
                      }
                    }}
                    id={`btn_delete_student_${student.id}`}
                    type="button"
                    title="De-enroll student"
                    className="p-1.5 text-slate-400 hover:text-red-650 hover:bg-neutral-100 rounded-lg cursor-pointer transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                {/* Meta details section */}
                <div className="my-4 py-3 border-y border-slate-100 space-y-2 text-xs">
                  
                  <div className="flex items-center gap-2 text-slate-600">
                    <School size={14} className="text-slate-400" />
                    <span className="font-semibold text-slate-755 truncate">
                      {classObj ? classObj.name : 'Unassigned'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-600">
                    <User size={14} className="text-slate-400 animate-pulse" />
                    <span className="truncate">Parent: <strong className="font-medium text-slate-700">{student.parentName}</strong></span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-650">
                    <Mail size={14} className="text-slate-400" />
                    <a 
                      href={`mailto:${student.parentEmail}`} 
                      className="hover:underline text-sky-600 truncate font-mono text-[10.5px]"
                    >
                      {student.parentEmail}
                    </a>
                  </div>

                  <div className="flex items-center gap-2 text-slate-600">
                    <Phone size={14} className="text-slate-400" />
                    <span className="font-mono text-[11px] truncate">{student.parentPhone}</span>
                  </div>

                </div>

                {/* Footer status summary link */}
                <div className="flex items-center justify-between text-[11px] text-slate-500">
                  <span className="inline-flex items-center gap-1.5 py-0.5 px-2 bg-slate-50 border border-slate-150 rounded-xs">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Active
                  </span>
                  
                  <span className="text-[10px] text-slate-400 font-medium">
                    Profile logged
                  </span>
                </div>

              </div>
            );
          })
        ) : (
          <div className="col-span-full py-16 text-center text-slate-450 text-sm">
            No pupils matching current query have been found.
          </div>
        )}
      </div>

    </div>
  );
}
