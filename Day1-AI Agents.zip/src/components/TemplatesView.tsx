/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NotificationTemplate } from '../types';
import { Settings, Save, AlertCircle, Sparkles, Copy, Sliders, ToggleLeft, ToggleRight } from 'lucide-react';

interface TemplatesViewProps {
  templates: NotificationTemplate[];
  onSaveTemplate: (updatedTemplate: NotificationTemplate) => void;
}

export default function TemplatesView({
  templates,
  onSaveTemplate
}: TemplatesViewProps) {

  const [activeTemplateType, setActiveTemplateType] = useState<'Absent' | 'Tardy'>('Absent');
  const [successMsg, setSuccessMsg] = useState<string>('');

  // Find active template settings
  const template = templates.find(t => t.type === activeTemplateType) || templates[0];

  // Forms state
  const [subject, setSubject] = useState(template.subjectTemplate);
  const [body, setBody] = useState(template.bodyTemplate);
  const [enabled, setEnabled] = useState(template.enabled);

  // Sync state if template type changes
  React.useEffect(() => {
    const freshTemplate = templates.find(t => t.type === activeTemplateType) || templates[0];
    setSubject(freshTemplate.subjectTemplate);
    setBody(freshTemplate.bodyTemplate);
    setEnabled(freshTemplate.enabled);
  }, [activeTemplateType, templates]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: NotificationTemplate = {
      ...template,
      subjectTemplate: subject.trim(),
      bodyTemplate: body.trim(),
      enabled
    };

    onSaveTemplate(updated);
    setSuccessMsg('Notification template configured successfully!');
    
    setTimeout(() => {
      setSuccessMsg('');
    }, 3000);
  };

  // Variable replacement test helper for Live Preview box
  const mockRenderPreview = () => {
    const studentName = 'Alexander Wright';
    const parentName = 'Sarah Wright';
    const classroomName = 'Grade 10 Science (A)';
    const dateStr = '2026-06-16';

    const renderedSubject = subject
      .replace(/{student_name}/g, studentName)
      .replace(/{parent_name}/g, parentName)
      .replace(/{classroom}/g, classroomName)
      .replace(/{date}/g, dateStr);

    const renderedBody = body
      .replace(/{student_name}/g, studentName)
      .replace(/{parent_name}/g, parentName)
      .replace(/{classroom}/g, classroomName)
      .replace(/{date}/g, dateStr);

    return { subject: renderedSubject, body: renderedBody };
  };

  const previewResult = mockRenderPreview();

  const handleCopyVariable = (variable: string) => {
    navigator.clipboard.writeText(variable);
    alert(`Copied variable placeholder: ${variable}`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="templates_manager_module">
      
      {/* Left panel: configure editor */}
      <div className="lg:col-span-7 bg-white border border-slate-150 rounded-2xl overflow-hidden shadow-xs">
        
        {/* Toggle tabs between triggers */}
        <div className="bg-slate-50 border-b border-slate-150 p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
          <div className="flex bg-slate-200/55 p-1 rounded-xl w-fit" id="template_type_selector_tabs">
            <button
              onClick={() => setActiveTemplateType('Absent')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-colors ${
                activeTemplateType === 'Absent'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-550 hover:text-slate-800'
              }`}
            >
              Absence Trigger Rule
            </button>
            <button
              onClick={() => setActiveTemplateType('Tardy')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-colors ${
                activeTemplateType === 'Tardy'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-550 hover:text-slate-800'
              }`}
            >
              Tardiness Trigger Rule
            </button>
          </div>

          <div className="flex items-center gap-2" id="trigger_rule_active_toggle">
            <button
              type="button"
              onClick={() => setEnabled(!enabled)}
              className="flex items-center gap-1.5 text-xs text-slate-700 font-semibold cursor-pointer"
            >
              {enabled ? (
                <>
                  <ToggleRight className="text-emerald-500 w-8 h-8" strokeWidth={1.5} />
                  Rule Active
                </>
              ) : (
                <>
                  <ToggleLeft className="text-slate-400 w-8 h-8" strokeWidth={1.5} />
                  Rule Disabled
                </>
              )}
            </button>
          </div>
        </div>

        {/* Email Editor Form */}
        <form onSubmit={handleSave} className="p-6 space-y-4">
          
          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              Subject Template Line
            </label>
            <input
              type="text"
              required
              id="input_template_subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1.5">
              Email Body Template
            </label>
            <textarea
              required
              id="input_template_body"
              rows={8}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:bg-white transition-all font-sans leading-relaxed custom-textarea"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-slate-100">
            <span className="text-xs text-emerald-600 font-medium" id="template_success_message">
              {successMsg}
            </span>

            <button
              type="submit"
              id="btn_save_template_rule"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-850 text-white rounded-xl shadow-xs font-semibold cursor-pointer text-xs select-none transition-all"
            >
              <Save size={14} />
              Save Notification Rule
            </button>
          </div>

        </form>

      </div>

      {/* Right panel: Variables helper & Realtime preview */}
      <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
        
        {/* Cheat sheet variable container */}
        <div className="bg-white border border-slate-150 rounded-2xl p-5 shadow-xs">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-widest mb-3 flex items-center gap-1.5">
            <Sliders size={14} />
            Placeholders Dictionary
          </h3>
          <p className="text-xs text-slate-500 mb-4 leading-normal">
            These variables will automatically populate with real-time student details before SMTP mailing. Click to copy and paste:
          </p>
          
          <div className="grid grid-cols-2 gap-2" id="placeholders_copyable_grid">
            {[
              { code: '{student_name}', label: 'Alexander Wright' },
              { code: '{parent_name}', label: 'Sarah Wright' },
              { code: '{classroom}', label: 'Grade 10 Science (A)' },
              { code: '{date}', label: '2026-06-16' },
            ].map(item => (
              <button
                key={item.code}
                type="button"
                onClick={() => handleCopyVariable(item.code)}
                className="p-2.5 rounded-xl border border-slate-150 hover:border-slate-350 bg-slate-50 hover:bg-white text-left transition-all cursor-pointer group"
                title="Click to Copy Placeholder"
              >
                <div className="flex justify-between items-center mb-0.5">
                  <code className="text-xs font-bold text-indigo-600 font-mono">{item.code}</code>
                  <Copy size={11} className="text-slate-400 group-hover:text-slate-600 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <span className="text-[10px] text-slate-450 block truncate">Renders as "{item.label}"</span>
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Dynamic Email Mock Preview */}
        <div className="bg-slate-900 text-slate-100 border border-slate-950 rounded-2xl overflow-hidden shadow-md flex-1 min-h-[280px] flex flex-col justify-between" id="realtime_live_preview_card">
          
          <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex justify-between items-center">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Sparkles className="text-amber-400" size={12} />
              Realtime Parsing Preview
            </span>
            <span className="text-[9px] font-mono text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded-full font-semibold border border-indigo-900 border-dashed">Local Client</span>
          </div>

          <div className="p-4 space-y-2 border-b border-slate-800/40 text-[11px] bg-slate-950/45 text-slate-300">
            <div>
              <span className="text-slate-500">Subject:</span>{' '}
              <span className="font-semibold text-white">{previewResult.subject || 'Empty subject line'}</span>
            </div>
            <div>
              <span className="text-slate-500">To:</span>{' '}
              <span className="text-slate-200">Sarah Wright &lt;sarah.w@example.com&gt;</span>
            </div>
          </div>

          <div className="p-5 flex-1 text-xs text-slate-300 leading-relaxed whitespace-pre-wrap select-all font-mono">
            {previewResult.body || 'Empty email message template. Please add text content.'}
          </div>

          <div className="bg-slate-950 p-3 border-t border-slate-800/60 text-[10px] text-slate-550 flex items-center gap-1 ml-1 text-slate-450 select-none">
            <AlertCircle size={10} />
            This is an accurate mock of the email triggered for "Alexander Wright".
          </div>

        </div>

      </div>

    </div>
  );
}
