/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { Student, Classroom, AttendanceRecord, NotificationLog } from '../types';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from 'recharts';
import { Users, AlertTriangle, Mail, CheckCircle, TrendingUp, Sparkles, School } from 'lucide-react';

interface DashboardViewProps {
  students: Student[];
  classrooms: Classroom[];
  records: AttendanceRecord[];
  logs: NotificationLog[];
  onNavigateToRegister: () => void;
}

export default function DashboardView({
  students,
  classrooms,
  records,
  logs,
  onNavigateToRegister
}: DashboardViewProps) {

  // Current Date Helper
  const todayStr = '2026-06-16'; // Reference current dates

  // 1. Calculations: General Metrics
  const totalStudentsCount = students.length;
  const totalClassesCount = classrooms.length;
  
  // Total emails sent
  const totalNotifications = logs.length;

  // Let's find today's marked attendance stats vs overall stats
  const activeRecordDays = useMemo(() => {
    const dates = new Set(records.map(r => r.date));
    return Array.from(dates).sort();
  }, [records]);

  const latestRecordedDay = useMemo(() => {
    if (activeRecordDays.length === 0) return '';
    return activeRecordDays[activeRecordDays.length - 1]; // Last entered day in data
  }, [activeRecordDays]);

  const latestStats = useMemo(() => {
    if (!latestRecordedDay) {
      return { presentRate: 0, present: 0, absent: 0, tardy: 0, excused: 0, total: 0 };
    }
    const dayRecords = records.filter(r => r.date === latestRecordedDay);
    if (dayRecords.length === 0) {
      return { presentRate: 0, present: 0, absent: 0, tardy: 0, excused: 0, total: 0 };
    }
    const present = dayRecords.filter(r => r.status === 'Present').length;
    const tardy = dayRecords.filter(r => r.status === 'Tardy').length;
    const excused = dayRecords.filter(r => r.status === 'Excused').length;
    const absent = dayRecords.filter(r => r.status === 'Absent').length;
    const total = dayRecords.length;

    // Attendance rate excludes Absent. Tardy, Excused and Present are counted as attended in standard rates.
    const attended = present + tardy + excused;
    const rate = total > 0 ? Math.round((attended / total) * 100) : 0;

    return {
      presentRate: rate,
      present,
      absent,
      tardy,
      excused,
      total
    };
  }, [records, latestRecordedDay]);

  // Overall Attendance Rate across all history
  const overallAttendanceRate = useMemo(() => {
    if (records.length === 0) return 0;
    const attended = records.filter(r => r.status !== 'Absent').length;
    return Math.round((attended / records.length) * 100);
  }, [records]);

  // 2. Chart Prep: Attendance Rate by Class
  const classChartData = useMemo(() => {
    return classrooms.map(c => {
      const classStudents = students.filter(s => s.classId === c.id);
      const studentIds = classStudents.map(s => s.id);
      const classRecords = records.filter(r => studentIds.includes(r.studentId));
      
      const total = classRecords.length;
      if (total === 0) {
        return { name: c.name, rate: 100, present: 0, absent: 0, total: 0 };
      }
      const attended = classRecords.filter(r => r.status !== 'Absent').length;
      const rate = Math.round((attended / total) * 100);
      
      return {
        name: c.name.split(' (')[0], // Trim subclass suffix
        rate: rate,
        total: total,
        absent: classRecords.filter(r => r.status === 'Absent').length
      };
    });
  }, [classrooms, students, records]);

  // 3. Chart Prep: Daily Attendance Trend
  const dailyTrendData = useMemo(() => {
    return activeRecordDays.map(date => {
      const dayRecords = records.filter(r => r.date === date);
      const total = dayRecords.length;
      const attended = dayRecords.filter(r => r.status !== 'Absent').length;
      const rate = total > 0 ? Math.round((attended / total) * 100) : 100;
      
      // Formatting date label (e.g. "Jun 15")
      const d = new Date(date + 'T00:00:00');
      const label = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' });

      return {
        date,
        label,
        'Attendance Rate %': rate
      };
    });
  }, [activeRecordDays, records]);

  // 4. Chart Prep: Status Breakdown
  const statusPieData = useMemo(() => {
    const present = records.filter(r => r.status === 'Present').length;
    const tardy = records.filter(r => r.status === 'Tardy').length;
    const excused = records.filter(r => r.status === 'Excused').length;
    const absent = records.filter(r => r.status === 'Absent').length;

    return [
      { name: 'Present', value: present, color: '#10B981' }, // emerald-500
      { name: 'Tardy', value: tardy, color: '#F59E0B' },   // amber-500
      { name: 'Excused', value: excused, color: '#3B82F6' }, // blue-500
      { name: 'Absent', value: absent, color: '#EF4444' }    // red-500
    ].filter(item => item.value > 0);
  }, [records]);

  // 5. Critical Interventions list (< 85% attendance rate)
  const criticalStudents = useMemo(() => {
    return students.map(student => {
      const studentRecords = records.filter(r => r.studentId === student.id);
      const total = studentRecords.length;
      if (total === 0) return { student, rate: 100, total: 0, absentCount: 0 };
      
      const attended = studentRecords.filter(r => r.status !== 'Absent').length;
      const rate = Math.round((attended / total) * 100);
      const absentCount = studentRecords.filter(r => r.status === 'Absent').length;

      return {
        student,
        rate,
        total,
        absentCount
      };
    })
    .filter(stat => stat.rate < 90) // Under 90%
    .sort((a, b) => a.rate - b.rate);
  }, [students, records]);

  return (
    <div className="space-y-6" id="dashboard_view">
      
      {/* Banner / Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center bg-radial from-slate-50 to-white border border-slate-200/80 rounded-2xl p-6 shadow-sm gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-150 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Live Monitoring
            </span>
            <span className="text-xs text-slate-450 font-mono">UTC: {todayStr}</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
            School Attendance Overview
          </h1>
          <p className="text-slate-500 text-sm mt-0.5">
            Real-time visual stats, critical intervention trackers, and automated parent notifications status.
          </p>
        </div>
        
        <button
          onClick={onNavigateToRegister}
          id="btn_quick_register"
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 border border-slate-950 text-white rounded-xl shadow-xs font-medium hover:bg-slate-850 hover:border-slate-900 transition-all cursor-pointer text-sm"
        >
          <School size={16} />
          Take Daily Attendance
        </button>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4" id="metrics_cards">
        
        {/* Core Stat 1 */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-450 text-xs font-medium uppercase tracking-wider block">Overall Presence</span>
            <span className="text-3xl font-extrabold text-slate-850 block mt-1 tracking-tight">
              {overallAttendanceRate}%
            </span>
            <span className="text-slate-500 text-xs mt-1 flex items-center gap-1">
              <TrendingUp size={12} className="text-emerald-500" />
              Target rate: 95%
            </span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-lg text-emerald-600">
            <CheckCircle size={24} />
          </div>
        </div>

        {/* Core Stat 2 */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-450 text-xs font-medium uppercase tracking-wider block">Latest Attendance</span>
            <span className="text-3xl font-extrabold text-slate-850 block mt-1 tracking-tight">
              {latestStats.presentRate ? `${latestStats.presentRate}%` : 'N/A'}
            </span>
            <span className="text-slate-500 text-xs mt-1 block truncate">
              {latestRecordedDay ? `Measured on ${new Date(latestRecordedDay + 'T00:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', timeZone: 'UTC' })}` : 'No records yet'}
            </span>
          </div>
          <div className="p-3 bg-sky-50 rounded-lg text-sky-600">
            <TrendingUp size={24} />
          </div>
        </div>

        {/* Core Stat 3 */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-450 text-xs font-medium uppercase tracking-wider block">Dispatched Emails</span>
            <span className="text-3xl font-extrabold text-slate-850 block mt-1 tracking-tight">
              {totalNotifications}
            </span>
            <span className="text-slate-550 text-xs mt-1 block">
              Automated parent alerts
            </span>
          </div>
          <div className="p-3 bg-indigo-50 rounded-lg text-indigo-600">
            <Mail size={24} />
          </div>
        </div>

        {/* Core Stat 4 */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-slate-450 text-xs font-medium uppercase tracking-wider block">Total Enrolled</span>
            <span className="text-3xl font-extrabold text-slate-850 block mt-1 tracking-tight">
              {totalStudentsCount}
            </span>
            <span className="text-slate-500 text-xs mt-1 block">
              In {totalClassesCount} registered sections
            </span>
          </div>
          <div className="p-3 bg-amber-50 rounded-lg text-amber-600">
            <Users size={24} />
          </div>
        </div>

      </div>

      {/* Charts section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="dashboard_charts">
        
        {/* Trend chart */}
        <div className="lg:col-span-2 bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="font-semibold text-slate-800 text-base">Attendance Trend Over Time</h3>
              <p className="text-xs text-slate-500">Continuous daily presence percentages across the last active sessions.</p>
            </div>
            <div className="flex gap-2">
              <span className="inline-flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 border border-slate-200 px-2 py-1 rounded-md">
                School Average
              </span>
            </div>
          </div>
          <div className="h-64 w-full" id="trend_chart_container">
            {dailyTrendData.length > 0 ? (
              <ResponsiveContainer width="99%" height="100%">
                <LineChart data={dailyTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <XAxis dataKey="label" stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <YAxis domain={[70, 100]} stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#0F172A', color: 'white', borderRadius: '8px', fontSize: '12px' }} />
                  <Line 
                    type="monotone" 
                    dataKey="Attendance Rate %" 
                    stroke="#0EA5E9" 
                    strokeWidth={2.5} 
                    dot={{ r: 4, strokeWidth: 1 }}
                    activeDot={{ r: 6 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-450 text-sm">
                No past attendance records found to plot trends.
              </div>
            )}
          </div>
        </div>

        {/* Status Breakdown (Pie) */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="font-semibold text-slate-800 text-base">Overall Distribution</h3>
            <p className="text-xs text-slate-500">Proportional breakdown of all archived attendance tallies.</p>
          </div>
          
          <div className="h-44 w-full flex items-center justify-center relative mt-3" id="pie_chart_container">
            {statusPieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={75}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {statusPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} logs`, 'Volume']} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-slate-400 text-sm">No distribution metrics.</div>
            )}
            
            {/* Legend override with actual numbers */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-slate-400 text-xs uppercase font-medium">Recorded Log</span>
              <span className="text-2xl font-bold text-slate-800">{records.length}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-100">
            {statusPieData.map((entry) => (
              <div key={entry.name} className="flex items-center gap-1.5 text-xs text-slate-600">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }}></span>
                <span className="truncate">{entry.name}: <strong className="text-slate-800">{entry.value}</strong></span>
              </div>
            ))}
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Section chart: Attendance Rate By Class */}
        <div className="lg:col-span-2 bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex flex-col">
          <div>
            <h3 className="font-semibold text-slate-800 text-base">Attendance Rate By Class Section</h3>
            <p className="text-xs text-slate-500">Average attendance percentage logged across active classes.</p>
          </div>
          <div className="h-64 w-full mt-4" id="class_chart_container">
            {classChartData.length > 0 ? (
              <ResponsiveContainer width="99%" height="100%">
                <BarChart data={classChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                  <XAxis dataKey="name" stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <YAxis domain={[50, 100]} stroke="#94A3B8" fontSize={11} tickLine={false} />
                  <Tooltip contentStyle={{ background: '#0F172A', color: 'white', borderRadius: '8px', fontSize: '11px' }} />
                  <Bar dataKey="rate" name="Attendance %" radius={[4, 4, 0, 0]}>
                    {classChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.rate >= 93 ? '#10B981' : entry.rate >= 88 ? '#3B82F6' : '#EF4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-450 text-sm">
                No classes registered to display metrics.
              </div>
            )}
          </div>
        </div>

        {/* Student Alerts Drawer/Sidebar Widget */}
        <div className="bg-white border border-slate-150 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="space-y-1 mb-4">
            <h3 className="font-semibold text-slate-800 text-base flex items-center gap-2">
              <AlertTriangle className="text-amber-500" size={18} />
              Intervention Flag alerts
            </h3>
            <p className="text-xs text-slate-500">Students with overall attendance rate below 90% triggering review.</p>
          </div>

          <div className="flex-1 overflow-y-auto max-h-56 pr-1 space-y-2.5 custom-scrollbar" id="critical_students_list">
            {criticalStudents.length > 0 ? (
              criticalStudents.map(({ student, rate, absentCount }) => (
                <div key={student.id} className="p-3 rounded-lg border border-red-100 bg-red-50/40 flex items-center justify-between gap-3 hover:bg-red-50 transition-colors">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center font-bold text-red-700 text-xs shrink-0">
                      {student.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <span className="font-semibold text-xs text-slate-800 block truncate">{student.name}</span>
                      <span className="text-[10px] text-slate-450 block truncate">Parent: {student.parentEmail}</span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-bold text-xs text-red-600 block">{rate}%</span>
                    <span className="text-[9px] font-mono text-slate-450 block">{absentCount} absences</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center py-8 text-center text-slate-400">
                <Sparkles size={24} className="text-emerald-500 mb-1" />
                <span className="text-xs font-semibold text-slate-700">Perfect Standing!</span>
                <span className="text-[10px] text-slate-450">All students are above 90% metrics.</span>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <div className="flex justify-between text-[11px] text-slate-500">
              <span>Low Performance Gate:</span>
              <span className="font-semibold text-slate-700">&lt; 90%</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
