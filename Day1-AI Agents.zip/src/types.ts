/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Student {
  id: string;
  name: string;
  rollNumber: string;
  classId: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  avatarColor: string;
}

export interface Classroom {
  id: string;
  name: string;
  grade: string;
  roomNumber: string;
}

export type AttendanceStatus = 'Present' | 'Absent' | 'Tardy' | 'Excused';

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  notes?: string;
  markedAt: string; // Timestamp
}

export interface NotificationLog {
  id: string;
  studentId: string;
  studentName: string;
  className: string;
  parentName: string;
  parentEmail: string;
  statusTrigger: 'Absent' | 'Tardy';
  date: string;
  emailSubject: string;
  emailBody: string;
  sentAt: string;
  status: 'Sent' | 'Delivered' | 'Failed';
}

export interface NotificationTemplate {
  id: string;
  type: 'Absent' | 'Tardy';
  subjectTemplate: string;
  bodyTemplate: string;
  enabled: boolean;
}

export interface AttendanceStats {
  presentCount: number;
  absentCount: number;
  tardyCount: number;
  excusedCount: number;
  totalActive: number;
}
