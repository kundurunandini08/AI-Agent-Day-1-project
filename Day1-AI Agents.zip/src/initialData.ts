import { Student, Classroom, AttendanceRecord, NotificationTemplate, NotificationLog } from './types';

export const INITIAL_CLASSROOMS: Classroom[] = [
  { id: 'c1', name: 'Grade 10 Science (A)', grade: '10th Grade', roomNumber: 'Room 201' },
  { id: 'c2', name: 'Grade 11 Literature (B)', grade: '11th Grade', roomNumber: 'Room 105' },
  { id: 'c3', name: 'Grade 12 Calculus (A)', grade: '12th Grade', roomNumber: 'Room 304' },
];

export const INITIAL_STUDENTS: Student[] = [
  // Class 1
  { id: 's1', name: 'Alexander Wright', rollNumber: 'S102401', classId: 'c1', parentName: 'Sarah Wright', parentEmail: 'sarah.w@example.com', parentPhone: '(555) 019-2831', avatarColor: 'bg-emerald-500' },
  { id: 's2', name: 'Benjamin Chen', rollNumber: 'S102402', classId: 'c1', parentName: 'Julia Chen', parentEmail: 'jchen23@example.com', parentPhone: '(555) 014-9982', avatarColor: 'bg-teal-500' },
  { id: 's3', name: 'Chloe Jenkins', rollNumber: 'S102403', classId: 'c1', parentName: 'David Jenkins', parentEmail: 'd.jenkins@example.com', parentPhone: '(555) 018-4729', avatarColor: 'bg-amber-500' },
  { id: 's4', name: 'Daniel Foster', rollNumber: 'S102404', classId: 'c1', parentName: 'Helen Foster', parentEmail: 'foster.h@example.com', parentPhone: '(555) 017-3810', avatarColor: 'bg-indigo-500' },
  { id: 's5', name: 'Emily Rodriguez', rollNumber: 'S102405', classId: 'c1', parentName: 'Carlos Rodriguez', parentEmail: 'carlos.r@example.com', parentPhone: '(555) 015-8127', avatarColor: 'bg-pink-500' },
  
  // Class 2
  { id: 's6', name: 'Fiona Gallagher', rollNumber: 'S112501', classId: 'c2', parentName: 'Monica Gallagher', parentEmail: 'mgallagher@example.com', parentPhone: '(555) 011-5524', avatarColor: 'bg-purple-500' },
  { id: 's7', name: 'Gabriel Silva', rollNumber: 'S112502', classId: 'c2', parentName: 'Alves Silva', parentEmail: 'alves.silva@example.com', parentPhone: '(555) 012-7741', avatarColor: 'bg-sky-500' },
  { id: 's8', name: 'Hannah Abbott', rollNumber: 'S112503', classId: 'c2', parentName: 'Michael Abbott', parentEmail: 'abbott.family@example.com', parentPhone: '(555) 013-6490', avatarColor: 'bg-rose-500' },
  { id: 's9', name: 'Ian Malcolm', rollNumber: 'S112504', classId: 'c2', parentName: 'Charlotte Malcolm', parentEmail: 'cmalcolm@example.com', parentPhone: '(555) 019-3312', avatarColor: 'bg-violet-500' },

  // Class 3
  { id: 's10', name: 'Jack Peterson', rollNumber: 'S122601', classId: 'c3', parentName: 'Robert Peterson', parentEmail: 'rpeterson@example.com', parentPhone: '(555) 014-2292', avatarColor: 'bg-blue-500' },
  { id: 's11', name: 'Katherine Howard', rollNumber: 'S122602', classId: 'c3', parentName: 'Thomas Howard', parentEmail: 't.howard@example.com', parentPhone: '(555) 016-1100', avatarColor: 'bg-orange-500' },
  { id: 's12', name: 'Liam Neeson', rollNumber: 'S122603', classId: 'c3', parentName: 'Nora Neeson', parentEmail: 'nora.n@example.com', parentPhone: '(555) 018-9012', avatarColor: 'bg-red-500' },
];

export const INITIAL_TEMPLATES: NotificationTemplate[] = [
  {
    id: 't1',
    type: 'Absent',
    subjectTemplate: 'Attendance Alert: {student_name} marked ABSENT today',
    bodyTemplate: 'Dear {parent_name},\n\nThis is an automated notification from the Student Attendance Portal to inform you that your child, {student_name}, was marked ABSENT for {classroom} on {date}.\n\nIf you are aware of this absence, please reply to this email or contact the school administration office to submit an excuse note.\n\nBest regards,\nSchool Attendance Administration',
    enabled: true,
  },
  {
    id: 't2',
    type: 'Tardy',
    subjectTemplate: 'Attendance Alert: {student_name} arrived LATE (Tardy)',
    bodyTemplate: 'Dear {parent_name},\n\nWe are reaching out to let you know that your child, {student_name}, arrived LATE (logged as Tardy) for {classroom} today, {date}.\n\nPunctual attendance is essential for academic continuity. If you have any questions or feel this is in error, please contact our support staff.\n\nBest regards,\nSchool Attendance Administration',
    enabled: true,
  },
];

// Seed attendance for the last 5 school days
// We will formulate dates backwards from a reference date
export const generateSeededAttendance = (): AttendanceRecord[] => {
  const records: AttendanceRecord[] = [];
  const students = INITIAL_STUDENTS;
  
  // Date values
  const dateStrings = [
    '2026-06-15', // Mon
    '2026-06-12', // Fri
    '2026-06-11', // Thu
    '2026-06-10', // Wed
    '2026-06-09', // Tue
  ];

  dateStrings.forEach((dateString) => {
    students.forEach((student) => {
      // Create random distribution:
      // 88% Present, 5% Absent, 5% Tardy, 2% Excused
      const rand = Math.random();
      let status: 'Present' | 'Absent' | 'Tardy' | 'Excused' = 'Present';
      let notes = '';

      if (rand < 0.06) {
        status = 'Absent';
        notes = Math.random() > 0.5 ? 'No call' : 'Awaiting note';
      } else if (rand < 0.12) {
        status = 'Tardy';
        notes = 'Arrived 15m late';
      } else if (rand < 0.14) {
        status = 'Excused';
        notes = 'Doctor appointment';
      }

      records.push({
        id: `att_${student.id}_${dateString}`,
        studentId: student.id,
        classId: student.classId,
        date: dateString,
        status,
        notes: notes || undefined,
        markedAt: `${dateString}T08:30:00.000`
      });
    });
  });

  return records;
};

export const INITIAL_NOTIFICATIONS: NotificationLog[] = [
  {
    id: 'not_1',
    studentId: 's3',
    studentName: 'Chloe Jenkins',
    className: 'Grade 10 Science (A)',
    parentName: 'David Jenkins',
    parentEmail: 'd.jenkins@example.com',
    statusTrigger: 'Absent',
    date: '2026-06-15',
    emailSubject: 'Attendance Alert: Chloe Jenkins marked ABSENT today',
    emailBody: 'Dear David Jenkins,\n\nThis is an automated notification from the Student Attendance Portal to inform you that your child, Chloe Jenkins, was marked ABSENT for Grade 10 Science (A) on 2026-06-15.\n\nIf you are aware of this absence, please reply to this email or contact the school administration office to submit an excuse note.\n\nBest regards,\nSchool Attendance Administration',
    sentAt: '2026-06-15T09:15:32-07:00',
    status: 'Delivered',
  },
  {
    id: 'not_2',
    studentId: 's8',
    studentName: 'Hannah Abbott',
    className: 'Grade 11 Literature (B)',
    parentName: 'Michael Abbott',
    parentEmail: 'abbott.family@example.com',
    statusTrigger: 'Tardy',
    date: '2026-06-15',
    emailSubject: 'Attendance Alert: Hannah Abbott arrived LATE (Tardy)',
    emailBody: 'Dear Michael Abbott,\n\nWe are reaching out to let you know that your child, Hannah Abbott, arrived LATE (logged as Tardy) for Grade 11 Literature (B) today, 2026-06-15.\n\nPunctual attendance is essential for academic continuity. If you have any questions or feel this is in error, please contact our support staff.\n\nBest regards,\nSchool Attendance Administration',
    sentAt: '2026-06-15T08:45:12-07:00',
    status: 'Delivered',
  },
];
