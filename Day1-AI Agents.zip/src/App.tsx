/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Student, Classroom, AttendanceRecord, NotificationTemplate, NotificationLog 
} from './types';
import { 
  INITIAL_CLASSROOMS, INITIAL_STUDENTS, INITIAL_TEMPLATES, INITIAL_NOTIFICATIONS, generateSeededAttendance 
} from './initialData';
import DashboardView from './components/DashboardView';
import AttendanceRegister from './components/AttendanceRegister';
import StudentsView from './components/StudentsView';
import NotificationsLogView from './components/NotificationsLogView';
import TemplatesView from './components/TemplatesView';

// Icons
import { 
  ClipboardCheck, Users, Mail, Settings, LayoutDashboard, RefreshCw, Sparkles, BookOpen 
} from 'lucide-react';

export default function App() {
  
  // Tab Navigation State
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Core Entity States
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [templates, setTemplates] = useState<NotificationTemplate[]>([]);
  const [logs, setLogs] = useState<NotificationLog[]>([]);

  // Toast / System updates state
  const [bannerNotice, setBannerNotice] = useState<string>('');

  // 1. Initial Load of seed databases from LocalStorage
  useEffect(() => {
    // Classrooms
    const storedClassrooms = localStorage.getItem('sa_classrooms');
    if (storedClassrooms) {
      setClassrooms(JSON.parse(storedClassrooms));
    } else {
      setClassrooms(INITIAL_CLASSROOMS);
      localStorage.setItem('sa_classrooms', JSON.stringify(INITIAL_CLASSROOMS));
    }

    // Students
    const storedStudents = localStorage.getItem('sa_students');
    if (storedStudents) {
      setStudents(JSON.parse(storedStudents));
    } else {
      setStudents(INITIAL_STUDENTS);
      localStorage.setItem('sa_students', JSON.stringify(INITIAL_STUDENTS));
    }

    // Attendance Records
    const storedRecords = localStorage.getItem('sa_records');
    if (storedRecords) {
      setRecords(JSON.parse(storedRecords));
    } else {
      const seeded = generateSeededAttendance();
      setRecords(seeded);
      localStorage.setItem('sa_records', JSON.stringify(seeded));
    }

    // Notification Templates
    const storedTemplates = localStorage.getItem('sa_templates');
    if (storedTemplates) {
      setTemplates(JSON.parse(storedTemplates));
    } else {
      setTemplates(INITIAL_TEMPLATES);
      localStorage.setItem('sa_templates', JSON.stringify(INITIAL_TEMPLATES));
    }

    // Email Dispatch logs
    const storedLogs = localStorage.getItem('sa_logs');
    if (storedLogs) {
      setLogs(JSON.parse(storedLogs));
    } else {
      setLogs(INITIAL_NOTIFICATIONS);
      localStorage.setItem('sa_logs', JSON.stringify(INITIAL_NOTIFICATIONS));
    }
  }, []);

  // 2. Clear Database / Reset Seed Action
  const handleResetData = () => {
    if (window.confirm('This action will reset your portal to initial sample student directory, custom templates and generated attendance history. Proceed?')) {
      localStorage.removeItem('sa_classrooms');
      localStorage.removeItem('sa_students');
      localStorage.removeItem('sa_records');
      localStorage.removeItem('sa_templates');
      localStorage.removeItem('sa_logs');

      const seeded = generateSeededAttendance();
      
      setClassrooms(INITIAL_CLASSROOMS);
      setStudents(INITIAL_STUDENTS);
      setRecords(seeded);
      setTemplates(INITIAL_TEMPLATES);
      setLogs(INITIAL_NOTIFICATIONS);

      localStorage.setItem('sa_classrooms', JSON.stringify(INITIAL_CLASSROOMS));
      localStorage.setItem('sa_students', JSON.stringify(INITIAL_STUDENTS));
      localStorage.setItem('sa_records', JSON.stringify(seeded));
      localStorage.setItem('sa_templates', JSON.stringify(INITIAL_TEMPLATES));
      localStorage.setItem('sa_logs', JSON.stringify(INITIAL_NOTIFICATIONS));

      triggerNotificationBanner('System reverted to clean demonstration databases.');
    }
  };

  // Helper notice triggered on updates
  const triggerNotificationBanner = (msg: string) => {
    setBannerNotice(msg);
    setTimeout(() => {
      setBannerNotice('');
    }, 4500);
  };

  // 3. Save Register handler
  const handleSaveAttendance = (
    newRecords: AttendanceRecord[], 
    generatedNotifications: NotificationLog[]
  ) => {
    // Replace matched records by key StudentID + Date or insert
    const recordsMap = new Map(records.map(r => [`${r.studentId}_${r.date}`, r]));
    
    newRecords.forEach(rec => {
      recordsMap.set(`${rec.studentId}_${rec.date}`, rec);
    });

    const updatedRecords = Array.from(recordsMap.values());
    setRecords(updatedRecords);
    localStorage.setItem('sa_records', JSON.stringify(updatedRecords));

    // Append notifications outbox items
    if (generatedNotifications.length > 0) {
      const updatedLogs = [...generatedNotifications, ...logs];
      setLogs(updatedLogs);
      localStorage.setItem('sa_logs', JSON.stringify(updatedLogs));

      triggerNotificationBanner(`Attendance logs archived! Sent ${generatedNotifications.length} automated alerts to parents.`);
    } else {
      triggerNotificationBanner('Attendance roll call updated successfully.');
    }
  };

  // 4. Enroll Student
  const handleAddStudent = (newStudent: Student) => {
    const updated = [...students, newStudent];
    setStudents(updated);
    localStorage.setItem('sa_students', JSON.stringify(updated));
    triggerNotificationBanner(`${newStudent.name} has been enrolled in section registrar.`);
  };

  // 5. Delete Student Profile
  const handleDeleteStudent = (studentId: string) => {
    const prevStudent = students.find(s => s.id === studentId);
    const updated = students.filter(s => s.id !== studentId);
    setStudents(updated);
    localStorage.setItem('sa_students', JSON.stringify(updated));
    if (prevStudent) {
      triggerNotificationBanner(`De-enrolled student: ${prevStudent.name}.`);
    }
  };

  // 6. Resend Logged Notification
  const handleResendNotification = (logId: string) => {
    const updated = logs.map(l => {
      if (l.id === logId) {
        return {
          ...l,
          sentAt: new Date().toISOString(), // Bump sent timestamp
          status: 'Delivered' as const
        };
      }
      return l;
    });

    setLogs(updated);
    localStorage.setItem('sa_logs', JSON.stringify(updated));
  };

  // 7. Config template rule
  const handleSaveTemplate = (updatedTemplate: NotificationTemplate) => {
    const updated = templates.map(t => t.id === updatedTemplate.id ? updatedTemplate : t);
    setTemplates(updated);
    localStorage.setItem('sa_templates', JSON.stringify(updated));
    triggerNotificationBanner(`Configured notification rule templates for ${updatedTemplate.type}.`);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans antialiased text-slate-900" id="portal_application_root">
      
      {/* Top Main Navigation Header Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-xs" id="main_header_bar">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            
            {/* Branding Logo */}
            <div className="flex items-center gap-3">
              <div className="bg-slate-900 p-2 rounded-xl text-white shadow-xs">
                <BookOpen size={20} className="stroke-[2]" />
              </div>
              <div>
                <span className="text-base font-extrabold tracking-tight text-slate-900 block font-display">
                  Attendance Portal
                </span>
                <span className="text-[10px] text-slate-450 block font-mono font-medium leading-none">
                  Smart Admin Panel
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex space-x-1" id="nav_links_desktop">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-all ${
                  activeTab === 'dashboard' 
                    ? 'bg-slate-950 text-white shadow-xs' 
                    : 'text-slate-655 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <LayoutDashboard size={14} />
                Dashboard Metrics
              </button>

              <button
                onClick={() => setActiveTab('register')}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-all ${
                  activeTab === 'register' 
                    ? 'bg-slate-950 text-white shadow-xs' 
                    : 'text-slate-655 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <ClipboardCheck size={14} />
                Daily Attendance Roll
              </button>

              <button
                onClick={() => setActiveTab('students')}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-all ${
                  activeTab === 'students' 
                    ? 'bg-slate-950 text-white shadow-xs' 
                    : 'text-slate-655 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Users size={14} />
                Student Directory
              </button>

              <button
                onClick={() => setActiveTab('notifications')}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-all ${
                  activeTab === 'notifications' 
                    ? 'bg-slate-950 text-white shadow-xs' 
                    : 'text-slate-655 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Mail size={14} />
                Mailing Outbox
              </button>

              <button
                onClick={() => setActiveTab('templates')}
                className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold select-none cursor-pointer transition-all ${
                  activeTab === 'templates' 
                    ? 'bg-slate-950 text-white shadow-xs' 
                    : 'text-slate-655 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Settings size={14} />
                Alert Rules
              </button>
            </nav>

            {/* Quick reset actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleResetData}
                id="btn_reset_demo_cache"
                title="Reset simulation data cache"
                className="p-1.5 text-slate-450 hover:text-red-550 hover:bg-slate-100 rounded-lg cursor-pointer transition-all"
              >
                <RefreshCw size={15} />
              </button>
            </div>

          </div>
        </div>
      </header>

      {/* Floating System-Wide Updates Alert Notice */}
      {bannerNotice && (
        <div className="relative bg-slate-900 text-white border-b border-slate-950 py-3 px-4 z-50 shadow-md animate-slide-down flex items-center justify-center text-xs font-medium gap-2" id="global_system_notice">
          <Sparkles size={14} className="text-amber-400" />
          <span>{bannerNotice}</span>
        </div>
      )}

      {/* Mobile Tab Icons rail */}
      <div className="md:hidden bg-white border-b border-slate-200 p-2 flex justify-around shadow-sm" id="nav_links_mobile">
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`flex flex-col items-center p-2 rounded-lg ${activeTab === 'dashboard' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}
        >
          <LayoutDashboard size={18} />
          <span className="text-[9px] mt-0.5">Stats</span>
        </button>
        <button 
          onClick={() => setActiveTab('register')}
          className={`flex flex-col items-center p-2 rounded-lg ${activeTab === 'register' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}
        >
          <ClipboardCheck size={18} />
          <span className="text-[9px] mt-0.5">Roll Call</span>
        </button>
        <button 
          onClick={() => setActiveTab('students')}
          className={`flex flex-col items-center p-2 rounded-lg ${activeTab === 'students' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}
        >
          <Users size={18} />
          <span className="text-[9px] mt-0.5">Pupils</span>
        </button>
        <button 
          onClick={() => setActiveTab('notifications')}
          className={`flex flex-col items-center p-2 rounded-lg ${activeTab === 'notifications' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}
        >
          <Mail size={18} />
          <span className="text-[9px] mt-0.5">Outbox</span>
        </button>
        <button 
          onClick={() => setActiveTab('templates')}
          className={`flex flex-col items-center p-2 rounded-lg ${activeTab === 'templates' ? 'text-slate-900 font-bold' : 'text-slate-400'}`}
        >
          <Settings size={18} />
          <span className="text-[9px] mt-0.5">Rules</span>
        </button>
      </div>

      {/* Primary Workspace Stage */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="primary_workspace_stage">
        
        {/* Render views on Active Tabs selector engine */}
        {activeTab === 'dashboard' && (
          <DashboardView
            students={students}
            classrooms={classrooms}
            records={records}
            logs={logs}
            onNavigateToRegister={() => setActiveTab('register')}
          />
        )}

        {activeTab === 'register' && (
          <AttendanceRegister
            students={students}
            classrooms={classrooms}
            records={records}
            templates={templates}
            onSaveAttendance={handleSaveAttendance}
          />
        )}

        {activeTab === 'students' && (
          <StudentsView
            students={students}
            classrooms={classrooms}
            onAddStudent={handleAddStudent}
            onDeleteStudent={handleDeleteStudent}
          />
        )}

        {activeTab === 'notifications' && (
          <NotificationsLogView
            logs={logs}
            onResendNotification={handleResendNotification}
            onNavigateToTemplates={() => setActiveTab('templates')}
          />
        )}

        {activeTab === 'templates' && (
          <TemplatesView
            templates={templates}
            onSaveTemplate={handleSaveTemplate}
          />
        )}

      </main>

      {/* Subtle bottom footer bar block */}
      <footer className="bg-white border-t border-slate-205 py-6 mt-12 shrink-0" id="portal_footer">
        <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-400 gap-3">
          <div>
            <span>School Attendance Hub &copy; 2026. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              Automated SMTP System Operational
            </span>
          </div>
        </div>
      </footer>

    </div>
  );
}
